//
//  Vertex.h
//  SampleShortestPath
//
//  Created by Zensar on 23/01/17.
//  Copyright © 2017 Zensar. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Vertex : NSObject
@property(nonatomic,strong)NSNumber* row;
@property(nonatomic,strong)NSNumber* column;
@property(nonatomic,strong)NSNumber* value;
@end
