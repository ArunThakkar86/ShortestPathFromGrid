//
//  AppDelegate.h
//  SampleShortestPath
//
//  Created by Zensar on 22/01/17.
//  Copyright © 2017 Zensar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

