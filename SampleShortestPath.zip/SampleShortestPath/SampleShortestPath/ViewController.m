//
//  ViewController.m
//  SampleShortestPath
//
//  Created by Zensar on 22/01/17.
//  Copyright © 2017 Zensar. All rights reserved.
//

#import "ViewController.h"
#import "Vertex.h"
@interface ViewController ()
@property(nonatomic,retain) NSMutableArray *gridArray;
@property(nonatomic,retain) NSMutableArray *gridMasterArray;
@property(nonnull,retain)NSMutableArray *traversalPathArray;
@end

@implementation ViewController{
    int currentRow;
    int currentColoumn;
    int maxAllowedTotal;
    int currentPathValue;
    int colLength;
    int rowLength;

}
@synthesize gridArray,gridMasterArray,traversalPathArray;


- (void)viewDidLoad {
    [super viewDidLoad];
  
    NSMutableArray *rowOne = [[NSMutableArray alloc] initWithObjects:@"3",@"4",@"1",@"2",@"8",@"6",nil];
    NSMutableArray *rowTwo = [[NSMutableArray alloc] initWithObjects:@"6",@"1",@"8",@"2",@"7",@"4",nil];
    NSMutableArray *rowThree = [[NSMutableArray alloc] initWithObjects:@"5",@"9",@"3",@"9",@"9",@"5",nil];
    NSMutableArray *rowFour = [[NSMutableArray alloc] initWithObjects:@"8",@"4",@"1",@"3",@"2",@"6",nil];
    NSMutableArray *rowFive = [[NSMutableArray alloc] initWithObjects:@"3",@"7",@"2",@"1",@"2",@"3",nil];
    gridArray = [NSMutableArray arrayWithObjects:rowOne,rowTwo,rowThree,rowFour,rowFive, nil];



/*
    NSMutableArray *rowOne = [[NSMutableArray alloc] initWithObjects:@"19",@"10",@"19",@"10",@"19",nil];
    NSMutableArray *rowTwo = [[NSMutableArray alloc] initWithObjects:@"21",@"23",@"20",@"19",@"12",nil];
    NSMutableArray *rowThree = [[NSMutableArray alloc] initWithObjects:@"20",@"12",@"20",@"11",@"10",nil];
    gridArray = [NSMutableArray arrayWithObjects:rowOne,rowTwo,rowThree, nil];
  */

    gridMasterArray = [[NSMutableArray alloc] init];
    currentRow = 0;
    currentColoumn = 0;
    currentPathValue = 0;
    maxAllowedTotal = 50;
    colLength = 6;
    rowLength = 5;

    [self fillGridData];
    [self getShortestPathValue];
}

-(void)fillGridData{
    for(int i = 0;i<rowLength;i++){
        NSMutableArray *innerArray = [[NSMutableArray alloc] init];
        for(int j = 0; j<colLength; j++){
            
            Vertex *v = [[Vertex alloc] init];
            v.column = [NSNumber numberWithInt:j];
            v.row = [NSNumber numberWithInt:i];
            v.value = gridArray[i][j];
            [innerArray addObject:v];
        }
        [gridMasterArray addObject:innerArray];
    }
}

-(Vertex *)getMinimumWeightegeNeighbourOfCurrentNode:(Vertex *)currentVertex{
    
    int col = [currentVertex.column intValue];
    int row = [currentVertex.row intValue];
   
    Vertex *adjucentUp;
    Vertex *adjucentDown;
    Vertex *hori_Next;
    
        if(row == 0){
            adjucentUp = gridMasterArray[rowLength-1][col+1];
        }else
            adjucentUp = gridMasterArray[row-1][col+1];
        if(row == rowLength-1){
             adjucentDown = gridMasterArray[0][col+1];
        }
        else
            adjucentDown = gridMasterArray[row+1][col+1];
    
        hori_Next = gridMasterArray[row][col+1];
    
    NSMutableArray *adjecentArray = [NSMutableArray arrayWithObjects:adjucentDown,adjucentUp,hori_Next, nil];
          Vertex *neighbourVertext = nil;
    
    Vertex *minValue = [self findMinVertex:adjecentArray value:hori_Next];
    if([minValue.value isEqual:hori_Next.value] && ![minValue.value isEqual:adjucentDown.value] && ![minValue.value isEqual:adjucentUp.value])
        neighbourVertext =  hori_Next;
    
    else if([minValue.value isEqual:adjucentDown.value] && ![minValue.value isEqual:hori_Next.value] && ![minValue.value isEqual:adjucentUp.value])
        neighbourVertext = adjucentDown;
    
    else if([minValue.value isEqual:adjucentUp.value] && ![minValue.value isEqual:adjucentDown.value] && ![minValue.value isEqual:adjucentDown.value])
        neighbourVertext = adjucentUp;

    
    else if ([hori_Next.value isEqual:adjucentUp.value]||[hori_Next.value isEqual:adjucentDown.value]||[adjucentDown.value isEqual:adjucentUp.value]){
        
        if([hori_Next.value isEqual:adjucentUp.value])
            neighbourVertext = [self handleSpecialCaseOfSameVertexValue:adjucentUp referenceToCurrentVertex:currentVertex];
        else if ([hori_Next.value isEqual:adjucentDown.value])
            neighbourVertext = [self handleSpecialCaseOfSameVertexValue:adjucentDown referenceToCurrentVertex:currentVertex];
        else if([adjucentDown.value isEqual:adjucentUp.value])
            neighbourVertext = [self handleSpecialCaseOfSameVertexValue:adjucentUp referenceToCurrentVertex:currentVertex];
        
    }
    
    
    return neighbourVertext;
}


-(Vertex *)findMinVertex:(NSMutableArray *)vertexArray value:(Vertex *)min{
    
    for(Vertex *v in vertexArray){
        if([v.value integerValue] <= [min.value integerValue])
            min = v;
    }
    return min;
}


-(Vertex *)handleSpecialCaseOfSameVertexValue:(Vertex *)duplicateVertex referenceToCurrentVertex:(Vertex *)current{
    
    int col = [current.column intValue];
    
    for(int i =0; i<rowLength; i++){
        Vertex *v = gridMasterArray[i][col];
        if([v.value intValue]<= [current.value intValue])
            current = v;
    }
    
    int newRow = [current.row intValue];
    int newCol = [current.column intValue];
    Vertex *vNH;
    Vertex *vNU;
    Vertex *vND;
    
    if(newRow == 0){
        vNU = gridMasterArray[rowLength-1][newCol+1];
    }else
        vNU = gridMasterArray[newRow-1][newCol+1];
    if(newRow == rowLength-1){
        vND = gridMasterArray[0][newCol+1];
    }
    else
        vND = gridMasterArray[newRow+1][newCol+1];

    vNH = gridMasterArray[newRow][newCol+1];
  
    if([vNU.value isEqual:duplicateVertex.value])
        return vNU;
    else if([vND.value isEqual:duplicateVertex.value])
        return vND;
    else if([vNH.value isEqual:duplicateVertex.value])
        return vNH;
    else
        return nil;
}

-(void)updateGridMasterArray:(NSMutableArray *)newArray Atcoloumn:(int)coloumn{
    
    colLength = colLength-1;
    for(int i = 0;i<newArray.count;i++){
        
        NSMutableArray *innerArray = [[NSMutableArray alloc] init];
        for(int j = 0; j<colLength; j++){
           
            Vertex *v = [[Vertex alloc] init];
            v.column = [NSNumber numberWithInt:j];
            v.row = [NSNumber numberWithInt:i];

            if(j == colLength-1){
                Vertex *newV = newArray[i];
                v.value = newV.value;
            }
            else
                v.value = gridArray[i][j];
            [innerArray addObject:v];
        }
        [gridMasterArray replaceObjectAtIndex:i withObject:innerArray];
        
    }
}



-(void)getShortestPathValue{
    for(int j = colLength-1-1; j>=0; j--){
         NSMutableArray *resultArray = [[NSMutableArray alloc] init];
        for(int i = 0; i<rowLength; i++){
            Vertex *v = gridMasterArray[i][j];
            
            Vertex *neighbourMin = [self getMinimumWeightegeNeighbourOfCurrentNode:v]; // store neighbour row and coloumn
            if([v.value integerValue] >50 || [neighbourMin.value integerValue]>50)
                continue;
            
            Vertex *newVertex = [[Vertex alloc] init];
            newVertex.row = v.row;
            newVertex.column = v.column;
            
                newVertex.value = [NSNumber numberWithInteger:[v.value integerValue] + [neighbourMin.value integerValue]];
                [resultArray addObject:newVertex];
            
            
        }
        BOOL isThresold = [self isThresoldReached:resultArray];
        [self setTraversalPathArrayFromArray:resultArray];
        if(!isThresold){
            [self updateGridMasterArray:resultArray Atcoloumn:colLength-1];
            }
        else
            break;
    }
 
    [self displayResult];
}


-(void)displayResult{
    
    Vertex *shortest = [traversalPathArray objectAtIndex:0];
    
    
    if([shortest.value intValue]<50)
        NSLog(@"****** IS Shortest Path  Available? : Yes");
    else
        NSLog(@"****** IS Shortest Path  Available? : No");
    
    
    NSLog(@"****** Shortest Path : %@",shortest.value);
    NSString *path = @"";
    for(Vertex *v in traversalPathArray){
        path = [NSString stringWithFormat:@"%@ - %d",path,[v.row intValue]+1];
        
    }
    path = [path substringFromIndex:2];
    NSLog(@"**** traversal path : %@",path);

}
-(BOOL)isThresoldReached:(NSMutableArray *)resultArray{
    BOOL isThresold = YES;
    for(Vertex *v in resultArray){
        if([v.value integerValue]<=50){
            isThresold = NO;
            break;
        }
        else
            isThresold = YES;
    }
    
    return isThresold;
}

-(void)setTraversalPathArrayFromArray:(NSMutableArray *)coloumnArray{
    
    NSArray *sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"value" ascending:YES]];
    [coloumnArray sortUsingDescriptors:sortDescriptors];
    Vertex *v = [coloumnArray objectAtIndex:0];
    if(!traversalPathArray)
        traversalPathArray = [[NSMutableArray alloc] init];
    [traversalPathArray insertObject:v atIndex:0];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
