//
//  TDDBtnBlue.m
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import "TDDBtnBlue.h"
#import "TDDColorManager.h"
#import "TDDFontManager.h"

@implementation TDDBtnBlue
- (void)awakeFromNib {
    [self setupUI];
}

- (void)setupUI {
    [self setBackgroundColor:[TDDColorManager blueColor]];
    
    self.layer.masksToBounds = NO;
    self.layer.cornerRadius = 2.0f;
    self.titleLabel.textColor = kDEFAULT_WHITE_COLOR;
    self.titleLabel.font = kDEFAULT_FONT;
    
    
}

- (void)setHighlighted:(BOOL)highlighted {
    [super setHighlighted:highlighted];
    
    if (highlighted) {
        [self setBackgroundColor:[TDDColorManager blueSelectedColor]];
    }
    else {
        [self setBackgroundColor:[TDDColorManager blueColor]];
    }
}

- (void)setEnabled:(BOOL)enabled{
    
    [super setEnabled:enabled];
    if(enabled)
        self.alpha = 1.0;
    else
        self.alpha = 0.5;
}

@end
