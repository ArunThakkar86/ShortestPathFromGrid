//
//  TDDLabelResult.m
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import "TDDLabelResult.h"
#import "TDDFontManager.h"
#import "TDDColorManager.h"

@implementation TDDLabelResult
- (void)awakeFromNib {
    [self setupUI];
}

- (void)setupUI {
    
    self.textColor = [TDDColorManager greenColor];
    self.font = [UIFont fontWithName:[TDDFontManager getDisplayFont] size:[TDDFontManager getFontSize_Display]];
}

@end
