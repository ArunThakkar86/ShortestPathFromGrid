//
//  TDDTextFieldGeneral.m
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import "TDDTextFieldGeneral.h"
#import "TDDColorManager.h"
#import "TDDFontManager.h"
@implementation TDDTextFieldGeneral

- (void)awakeFromNib {
    [self setupUI];
}

- (void)setupUI {
    
    self.keyboardType = UIKeyboardTypeNumberPad;
    self.textAlignment = NSTextAlignmentCenter;
    self.borderStyle = UITextBorderStyleLine;
    self.backgroundColor = kDEFAULT_LIGHT_GRAY_COLOR;
    self.font = kDEFAULT_FONT;
    
}


@end
