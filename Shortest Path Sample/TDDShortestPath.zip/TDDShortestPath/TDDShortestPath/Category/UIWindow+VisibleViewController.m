//
//  UIWindow+VisibleViewController.m
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.

#import "UIWindow+VisibleViewController.h"

@implementation UIWindow (VisibleViewController)

/*---------------------------------------------------------------------------
 * visibleViewController
 * This method will return root view controller of UIWindow.
 *--------------------------------------------------------------------------*/

+ (UIViewController *)visibleViewController {
    UIViewController *rootViewController = [[[UIApplication sharedApplication] keyWindow] rootViewController];
    return [UIWindow getVisibleViewControllerFrom:rootViewController];
}

/*---------------------------------------------------------------------------
 * visibleViewController
 * This method will currently visible view controller of root view controller.
 *--------------------------------------------------------------------------*/

+ (UIViewController *) getVisibleViewControllerFrom:(UIViewController *) vc {
    if ([vc isKindOfClass:[UINavigationController class]]) {
        return [UIWindow getVisibleViewControllerFrom:[((UINavigationController *) vc) visibleViewController]];
    } else if ([vc isKindOfClass:[UITabBarController class]]) {
        return [UIWindow getVisibleViewControllerFrom:[((UITabBarController *) vc) selectedViewController]];
    } else {
        if (vc.presentedViewController) {
            return [UIWindow getVisibleViewControllerFrom:vc.presentedViewController];
        } else {
            return vc;
        }
    }
}

@end
