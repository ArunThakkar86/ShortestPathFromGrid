//
//  Constant.h
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#ifndef Constant_h
#define Constant_h

// AppDelegate object
#define AppDelegateObj ((AppDelegate *)[[UIApplication sharedApplication] delegate])

// standard user defaults
#define kUserDefaults [NSUserDefaults standardUserDefaults];

#pragma mark - APP STATIC VARIABLES -

// ALERT TAGS
#define kTitle_OK @"OK"
#define kTitle_Cancel @"Cancel"

#define kRow_Min 1
#define kRow_Max 5
#define kCol_Min 5
#define kCol_Max 10

#define kThresold 50

#define kDefaultRow @"5"
#define kDefaultColoumn @"6"
#define kRow 5
#define kCol 6


#pragma mark - Alert Messages
#define kInvalid_Coloumn @"Coloumn value should be greater than 4 and should not more than 10"
#define kInvalid_Row @"Row value should be greater than 0 and should not more than 5"
#define kInvalid_Grid @"Row or coloumn should not be blank"
#pragma mark - LOG SYSTEM SETUP -

#ifdef DEBUG
#define TDDLog( s, ... ) NSLog( @"<%p %@:(%d)> %@", self, [[NSString stringWithUTF8String:__FILE__] lastPathComponent], __LINE__, [NSString stringWithFormat:(s), ##__VA_ARGS__] )
#else
#define TDDLog( s, ... )
#endif


#endif /* Constant_h */
