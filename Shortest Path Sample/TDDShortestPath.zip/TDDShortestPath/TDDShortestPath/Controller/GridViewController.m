//
//  GridViewController.m
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import "GridViewController.h"
#import "TDDCustomCell.h"
#import "TDDAppUtility.h"
#import "TDDVertex.h"
#import "TDDShortestPathManager.h"

@interface GridViewController ()

@end

@implementation GridViewController{
    int row;
    int coloumn;
    BOOL isDefault;
}
@synthesize gridMasterArray,defaultArray;
static NSString * const reuseIdentifier = @"cell";

// initialization of default values on view load.
- (void)viewDidLoad {
    [super viewDidLoad];
    row = 0;
    coloumn = 0;
    _viewResult.hidden = YES;
    isDefault = NO;
    
}

# pragma mark - Button Action

/*---------------------------------------------------------------------------
 * onClick_Go
 * This function will display grid or Matrix based on entered row and coloumn
 *--------------------------------------------------------------------------*/

- (IBAction)onClick_Go:(id)sender {
    
    [_txtCol resignFirstResponder];
    [_txtRow resignFirstResponder];
    if([self validateRowAndColumnEntry]){
        row = [_txtRow.text intValue];
        coloumn = [_txtCol.text intValue];
         _viewResult.hidden = NO;
        _lblGridMessage.hidden = NO;
        [self initializeGridArrayWithRow:row AndColoumn:coloumn];
        [self.collectionView reloadData];
        _btnGo.enabled = false;
        _btnDefault.enabled = false;
    }
        
}

/*---------------------------------------------------------------------------
 * onClick_FindShortestPath
 * This function will check values inserted in Grid and calculate shortest 
 * path based on values entered in Grid
 *--------------------------------------------------------------------------*/

- (IBAction)onClick_FindShortestPath:(id)sender{
    
    if([self isValidaGridEntries:gridMasterArray]){
        TDDLog(@"Finding shortest path");
        [self showShortestPath];
    }else
        [TDDAppUtility showAlertWithMessage:kInvalid_Grid cancelTitle:@"OK"];
}


/*---------------------------------------------------------------------------
 * clearAll
 * This function will restove all values to default.
 *--------------------------------------------------------------------------*/
- (IBAction)clearAll:(id)sender{
    
    row = 0;
    coloumn = 0;
    _txtCol.text = @"";
    _txtRow.text = @"";
    isDefault = NO;
    _lblPathExist.text = @"";
    _lblPathCost.text = @"";
    _lblTraversalRow.text = @"";
    _btnGo.enabled = true;
    _btnDefault.enabled = true;
    [gridMasterArray removeAllObjects];
    gridMasterArray = nil;
    [self.collectionView reloadData];
    
}

/*---------------------------------------------------------------------------
 * setDefault
 * This function will used to fill all default values to row, column and to
 * grid as well.
 *--------------------------------------------------------------------------*/
- (IBAction)setDefault:(id)sender{
    row = kRow;
    coloumn = kCol;
    _txtRow.text = kDefaultRow;
    _txtCol.text = kDefaultColoumn;
    isDefault = YES;
    [self initializeGridArrayWithRow:kRow AndColoumn:kCol];
    NSMutableArray *rowOne = [[NSMutableArray alloc] initWithObjects:@"3",@"4",@"1",@"2",@"8",@"6",nil];
    NSMutableArray *rowTwo = [[NSMutableArray alloc] initWithObjects:@"6",@"1",@"8",@"2",@"7",@"4",nil];
    NSMutableArray *rowThree = [[NSMutableArray alloc] initWithObjects:@"5",@"9",@"3",@"9",@"9",@"5",nil];
    NSMutableArray *rowFour = [[NSMutableArray alloc] initWithObjects:@"8",@"4",@"1",@"3",@"2",@"6",nil];
    NSMutableArray *rowFive = [[NSMutableArray alloc] initWithObjects:@"3",@"7",@"2",@"8",@"6",@"4",nil];
    defaultArray = [NSMutableArray arrayWithObjects:rowOne,rowTwo,rowThree,rowFour,rowFive, nil];
    [self.collectionView reloadData];
    
    if([self validateRowAndColumnEntry]){
        row = [_txtRow.text intValue];
        coloumn = [_txtCol.text intValue];
        _viewResult.hidden = NO;
        _lblGridMessage.hidden = NO;
        _btnGo.enabled = false;
        _btnDefault.enabled = false;

    }

    
}

#pragma mark -  Data source Initializing

/*---------------------------------------------------------------------------
 * initializeGridArrayWithRow
 * This function will create Vertex object initializing nill and store to 
 * Grid Master Array.
 *--------------------------------------------------------------------------*/
- (void)initializeGridArrayWithRow:(int)rowN AndColoumn:(int)coloumnN{
    if(!gridMasterArray)
        gridMasterArray = [[NSMutableArray alloc] init];
    
    for(int i=0;i<rowN;i++){
        NSMutableArray *rowArray = [[NSMutableArray alloc] init];
        for(int j =0; j<coloumnN; j++){
            TDDVertex *v = [[TDDVertex alloc] init];
            [rowArray addObject:v];
        }
        [gridMasterArray addObject:rowArray];
    }
    TDDLog(@"%@",[gridMasterArray description]);
}


# pragma mark - Field Validation

/*---------------------------------------------------------------------------
 * validateRowAndColumnEntry
 * This function will validate entry of row and column and display
 * Grid/Matrix if both values of row and coloum are valid
 *--------------------------------------------------------------------------*/
- (BOOL)validateRowAndColumnEntry{
    BOOL isValid = NO;
    isValid = [self isValidRow];
    if(isValid){
        isValid = [self isValidColoumn];
        if(isValid)
            return isValid;
        else{
           
            _txtCol.text = @"";
            coloumn = 0;
             _viewResult.hidden = YES;
            _lblGridMessage.hidden = YES;
            [TDDAppUtility showAlertWithMessage:kInvalid_Coloumn cancelTitle:@"OK"];
            [self.collectionView reloadData];
        }
    }
    else{
      
        _txtRow.text = @"";
        row = 0;
         _viewResult.hidden = YES;
        _lblGridMessage.hidden = YES;
        [TDDAppUtility showAlertWithMessage:kInvalid_Row cancelTitle:@"OK"];
        [self.collectionView reloadData];
    }
    return isValid;
}

/*---------------------------------------------------------------------------
 * isValidRow
 * This is core function to validate entry of row if entry is
 * valid then return true else it will return false
 *--------------------------------------------------------------------------*/
- (BOOL)isValidRow{
    int entryRow = [_txtRow.text intValue];
    if(entryRow >= kRow_Min && entryRow <= kRow_Max)
        return YES;
    else
        return NO;
}

/*---------------------------------------------------------------------------
 * isValidColoumn
 * This is core function to validate entry of coloumn if entry is
 * valid then return true else it will return false
 *--------------------------------------------------------------------------*/
- (BOOL)isValidColoumn{
    int entryCol = [_txtCol.text intValue];
    if(entryCol >= kCol_Min && entryCol <= kCol_Max)
        return YES;
    else
        return NO;
    
}

/*---------------------------------------------------------------------------
 * isValidaGridEntries
 * This is core function to validate all values entered in grid/matrix. 
 * It will not allow blank or nill value to calculate shortest path
 *--------------------------------------------------------------------------*/
- (BOOL)isValidaGridEntries:(NSMutableArray *)gridArray{
    
    if(gridArray.count >0){
    for(int i = 0; i< gridArray.count; i++){
        NSArray *innerArray = [gridArray objectAtIndex:i];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"value == nil OR value == ''"];
        NSArray *results = [innerArray filteredArrayUsingPredicate:predicate];
        if(results.count >0){
            return false;
        }
    }
        return  YES;
    }
    return NO;
}

#pragma mark - Collection View Data source and Delegate


/*---------------------------------------------------------------------------
 * numberOfSectionsInCollectionView
 * This is datasource method which represents section or coloumn of Grid
 *--------------------------------------------------------------------------*/
- (NSInteger)numberOfSectionsInCollectionView: (UICollectionView *)collectionView {
    
    if(isDefault){
        NSMutableArray *innerArray = [defaultArray objectAtIndex:0];
        return innerArray.count;
    }
    else
        return coloumn;
}

/*---------------------------------------------------------------------------
 * numberOfItemsInSection
 * This is datasource method which represents items or row of Grid
 *--------------------------------------------------------------------------*/
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if(isDefault)
        return defaultArray.count;
    else
        return row;

}

/*---------------------------------------------------------------------------
 * cellForItemAtIndexPath
 * This is datasource method which represents actual cell of grid
 *--------------------------------------------------------------------------*/
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    TDDCustomCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    cell.tag = indexPath.section;
    cell.txtIndex.tag = indexPath.item;
    cell.txtIndex.text = @"";
    if(isDefault){
        cell.txtIndex.text = defaultArray[indexPath.item][indexPath.section];
        TDDVertex *vtx = gridMasterArray[indexPath.item][indexPath.section];
        NSString *str = defaultArray[indexPath.item][indexPath.section];
        vtx.value = [NSNumber numberWithInteger:[str integerValue]];
        vtx.row = [NSNumber numberWithInteger:indexPath.item];
        vtx.column = [NSNumber numberWithInteger:indexPath.section];
    }
    
    return cell;
}


# pragma mark - Text Field Deleagte Methods

/*---------------------------------------------------------------------------
 * textFieldDidEndEditing
 * This is textfield delegate method which will be used to store value 
 * inserted in to each cell of grid to Grid Master Array by assigning to 
 * related vertex.
 *--------------------------------------------------------------------------*/
- (void)textFieldDidEndEditing:(UITextField *)textField{
    
    if(textField == _txtRow || textField == _txtCol){
    
    }
    else {
        UICollectionViewCell *selectedCell = (UICollectionViewCell *)[[textField superview]superview];
        TDDLog(@"Row : %ld",(long)textField.tag);
        TDDLog(@"Section :%ld",selectedCell.tag);
        
        NSNumber *number = [NSNumber numberWithInt:[textField.text intValue]];
        TDDVertex *v = gridMasterArray[textField.tag][selectedCell.tag];
        v.value = number;
        v.row = [NSNumber numberWithInteger:textField.tag];
        v.column = [NSNumber numberWithInteger:selectedCell.tag];
        TDDLog(@"%@",[gridMasterArray description]);

    }
}

/*---------------------------------------------------------------------------
 * showShortestPath
 * This method will call find Shortestpath function of TDDShortestPathManager
 * class and will be execute its completion handler (call back) and display
 * output
 *--------------------------------------------------------------------------*/

- (void)showShortestPath{
    
    NSMutableArray *gridArray = [[NSMutableArray alloc] initWithArray:gridMasterArray copyItems:YES];
    
    [TDDShortestPathManager findShortestPath:row andColoumn:coloumn forGrid:gridArray completionHandler:^(NSDictionary *responseDictionary) {
        if(responseDictionary){
            
            _lblPathExist.text = [responseDictionary objectForKey:@"PathExist"];
            NSNumber *totalCost = [responseDictionary objectForKey:@"MinTotalCost"];
            _lblPathCost.text = totalCost.stringValue;
            _lblTraversalRow.text = [responseDictionary objectForKey:@"TraversalPath"];
        }
            
        TDDLog(@"%@",responseDictionary);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
