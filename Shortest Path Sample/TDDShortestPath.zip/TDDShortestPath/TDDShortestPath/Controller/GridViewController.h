//
//  GridViewController.h
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GridViewController : UIViewController<UICollectionViewDataSource, UITextFieldDelegate>
@property(nonatomic,weak)IBOutlet UICollectionView *collectionView;
@property(nonatomic,strong)NSMutableArray *gridMasterArray;
@property(nonatomic,strong)NSMutableArray *defaultArray;
@property(nonatomic,weak)IBOutlet UITextField *txtRow;
@property(nonatomic,weak)IBOutlet UITextField *txtCol;
@property(nonatomic,weak)IBOutlet UILabel *lblPathExist;
@property(nonatomic,weak)IBOutlet UILabel *lblPathCost;
@property(nonatomic,weak)IBOutlet UILabel *lblTraversalRow;
@property(nonatomic,weak)IBOutlet UIView *viewResult;
@property(nonatomic,weak)IBOutlet UILabel *lblGridMessage;
@property(nonatomic,weak)IBOutlet UIButton *btnGo;
@property(nonatomic,weak)IBOutlet UIButton *btnDefault;

- (void)showShortestPath;
- (IBAction)setDefault:(id)sender;
- (void)initializeGridArrayWithRow:(int)rowN AndColoumn:(int)coloumnN;
- (IBAction)onClick_Go:(id)sender;
- (IBAction)onClick_FindShortestPath:(id)sender;
- (IBAction)clearAll:(id)sender;
- (BOOL)validateRowAndColumnEntry;
- (BOOL)isValidRow;
- (BOOL)isValidColoumn;
- (BOOL)isValidaGridEntries:(NSMutableArray *)gridArray;

@end
