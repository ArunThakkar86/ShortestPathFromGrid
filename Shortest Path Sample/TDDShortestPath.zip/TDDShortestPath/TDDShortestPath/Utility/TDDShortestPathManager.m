//
//  TDDShortestPathManager.m
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import "TDDShortestPathManager.h"
#import "TDDVertex.h"
#import "TDDAppUtility.h"
@implementation TDDShortestPathManager{
}

/*---------------------------------------------------------------------------
 * findShortestPath
 * This method takes element of two column (starting with coloumn length -1) 
 * one by one and find its child(adjecent node  up, next or down) with 
 * lowest value then update coloumn with possible lowest sum.
 * once the operation complete, it format result and return result back
 *--------------------------------------------------------------------------*/

+ (void)findShortestPath:(int)row andColoumn: (int)coloumn forGrid:(NSMutableArray * )gridMasterArray completionHandler:(void (^) (NSDictionary *responseDictionary))completionHandler{

    if(gridMasterArray.count >0){
        
        NSMutableArray *gridArray = [TDDShortestPathManager getDeepCopiedGridarrayFromMasterGridArray:gridMasterArray];
         BOOL _isPathExist = YES;
    for(int j= coloumn-1-1; j>=0; j--){
        for(int i = 0; i<row; i++){
            
            TDDVertex *vtxParent = gridArray[i][j];
            
            if([vtxParent.value integerValue] >kThresold){
                _isPathExist = NO;
                continue;
            }
             else{
                 
                TDDVertex *vtxChild = [self findMinChildVertexNodeOfVertex:vtxParent FromArray:gridArray];
                 /** updating coloumn with new value**/
                 vtxParent.value = [NSNumber numberWithInteger:[vtxParent.value integerValue] + [vtxChild.value integerValue]];
                 if([vtxParent.value integerValue]>kThresold){
                     _isPathExist = NO;
                     continue;
                 }
                 else {
                     _isPathExist = YES;
                     
                 }
             }
        }
        
    }
        
        TDDVertex *vtxStartNode = [TDDShortestPathManager findStartingNodeFromGrid:gridArray];
        NSMutableDictionary *dctResult;
    
        if(_isPathExist){
            dctResult = [TDDShortestPathManager formatSuccessResult:gridArray ofColoumn:coloumn WithStartingVertext:vtxStartNode];
        } else{
            dctResult = [TDDShortestPathManager formatFailureResult:gridMasterArray ofColoumn:coloumn WithStartingVertext:vtxStartNode];
        }
        
        completionHandler(dctResult);
    }
    
}

/*---------------------------------------------------------------------------
 * getDeepCopiedGridarrayFromMasterGridArray
 * This method is used to make deep copy of original gridmaster array
 * as the operation perforemd on array may change values
 *--------------------------------------------------------------------------*/

+ (NSMutableArray *)getDeepCopiedGridarrayFromMasterGridArray:(NSMutableArray *)gridMasterArray{
    NSMutableArray *gridArray = [[NSMutableArray alloc] init];
    for(NSMutableArray *innerArray in gridMasterArray){
        
        NSMutableArray *rowArray = [[NSMutableArray alloc] initWithArray:innerArray copyItems:YES];
        [gridArray addObject:rowArray];
    }
    return gridArray;
}


/*---------------------------------------------------------------------------
 * findMinChildVertexNodeOfVertex
 * This method takes two arguments current node and grid array
 * and return child node with minimum value of current node from grid
 *--------------------------------------------------------------------------*/
+ (TDDVertex *)findMinChildVertexNodeOfVertex:(TDDVertex *)vtxCurrent FromArray:(NSMutableArray *)array{
    
    NSInteger currentRow = [vtxCurrent.row integerValue];
    NSInteger currentCol = [vtxCurrent.column integerValue];
    NSInteger rowLength = array.count;
    
    TDDVertex *vtxUp;
    TDDVertex *vtxNext;
    TDDVertex *vtxDown;
    
    if(currentRow == 0){
        vtxUp = array[rowLength-1][currentCol+1];
    }else
        vtxUp = array[currentRow-1][currentCol+1];
    
    if(currentRow == rowLength-1){
        vtxDown = array[0][currentCol+1];
    }
    else
        vtxDown = array[currentRow+1][currentCol+1];
    
    vtxNext = array[currentRow][currentCol+1];
    
    /** Finding minimum of three.
     could have been done through MIN(A, MIN(<#A#>, B)) if VTX would be integer.
     Used following manual approch as we need to compare three objects.
     **/
    
    TDDVertex *vtxmin;
    if(vtxUp.value < vtxNext.value)
        vtxmin = vtxUp;
    else
        vtxmin = vtxNext;
    
    if(vtxmin.value < vtxDown.value)
        return vtxmin;
    else
        return vtxDown;
    
    
}


/*---------------------------------------------------------------------------
 * findStartingNodeFromGrid
 * This method is used to identify the node to start traversal
 * It takes updated grid array, get first coloumn sub array and then sort it 
 * to find minimum from the array at index 0.
 *--------------------------------------------------------------------------*/

+ (TDDVertex *)findStartingNodeFromGrid:(NSMutableArray *)gridArray{
    
    NSMutableArray *coloumnArray = [TDDShortestPathManager seprateFirstColoumnElementFromGrid:gridArray];
    NSArray *sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"value" ascending:YES]];
    [coloumnArray sortUsingDescriptors:sortDescriptors];
    TDDVertex *vtxStartNode = [coloumnArray objectAtIndex:0];
    return vtxStartNode;
}


/*---------------------------------------------------------------------------
 * seprateFirstColoumnElementFromGrid
 * This method is used to seprate elements of first coloumn out of grid.
 *--------------------------------------------------------------------------*/

+ (NSMutableArray *)seprateFirstColoumnElementFromGrid:(NSMutableArray *)gridArray{
    
    NSMutableArray *firstColoumnArray = [[NSMutableArray alloc] init];
    for(int i = 0; i<gridArray.count;i++){
        TDDVertex *vtxFirstColoumn = gridArray[i][0];
        [firstColoumnArray addObject:vtxFirstColoumn];
    }
    return  firstColoumnArray;
}


/*---------------------------------------------------------------------------
 * formatSuccessResult
 * This method is used to caluclate total cost, shortest path and 
 * when path exist for sure i.e total cost does not cross thresold cost
 *--------------------------------------------------------------------------*/
+ (NSMutableDictionary *)formatSuccessResult:(NSMutableArray *)gridArray ofColoumn:(int)coloumn WithStartingVertext:(TDDVertex *)vtxStartNode{
    
    NSInteger currentCol;
    NSString *traversalPath = @"";
    traversalPath = [NSString stringWithFormat:@"%@ - %d",traversalPath,[vtxStartNode.row intValue]+1];;
    TDDVertex *vtxChild = vtxStartNode;
    do {
        vtxChild = [self findMinChildVertexNodeOfVertex:vtxChild FromArray:gridArray];
        traversalPath = [NSString stringWithFormat:@"%@ - %d",traversalPath,[vtxChild.row intValue]+1];
        currentCol = [vtxChild.column integerValue];
        
    } while (currentCol < coloumn-1);
    TDDLog(@"TraversalPath : %@",traversalPath);
    
    NSMutableDictionary *resultDictionary = [[NSMutableDictionary alloc] init];
    [resultDictionary setObject:@"Yes" forKey:@"PathExist"];
    [resultDictionary setObject:vtxStartNode.value forKey:@"MinTotalCost"];
    if(traversalPath.length >2)
        traversalPath = [traversalPath substringFromIndex:2];
    [resultDictionary setObject:traversalPath forKey:@"TraversalPath"];
    return resultDictionary;
    
}

/*---------------------------------------------------------------------------
 * formatFailureResult
 * This method is used to caluclate total cost, uncompleted path as 
 * path surely does not exist i.e total cost cross thresold cost
 *--------------------------------------------------------------------------*/
+ (NSMutableDictionary *)formatFailureResult:(NSMutableArray *)gridArray ofColoumn:(int)coloumn WithStartingVertext:(TDDVertex *)vtxStartNode{
    
    NSInteger totalCost = 0;
    NSInteger finalCost = 0;
    NSInteger currentCol;
    NSString *traversalPath = @"";
    
    int row = [vtxStartNode.row intValue];
    int col = [vtxStartNode.column intValue];
    TDDVertex *vtxChild = gridArray[row][col];
    do {
        totalCost = totalCost + [vtxChild.value integerValue];
        if(totalCost <= 50){
            finalCost = finalCost+[vtxChild.value integerValue];
            vtxChild = [self findMinChildVertexNodeOfVertex:vtxChild FromArray:gridArray];
            traversalPath = [NSString stringWithFormat:@"%@ - %d",traversalPath,[vtxChild.row intValue]+1];
            currentCol = [vtxChild.column integerValue];
        }
        else{
            break;
        }
        
    } while (currentCol < coloumn-1);
    TDDLog(@"TraversalPath : %@",traversalPath);
    
    NSMutableDictionary *resultDictionary = [[NSMutableDictionary alloc] init];
    [resultDictionary setObject:@"NO" forKey:@"PathExist"];
    [resultDictionary setObject:[NSNumber numberWithInteger:finalCost] forKey:@"MinTotalCost"];
    if(traversalPath.length >2)
        traversalPath = [traversalPath substringFromIndex:2];
    [resultDictionary setObject:traversalPath forKey:@"TraversalPath"];
    return resultDictionary;
    
}

@end
