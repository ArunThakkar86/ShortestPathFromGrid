//
//  TDDFontManager.h
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#define kDEFAULT_FONT [UIFont fontWithName:@"Halvetica" size:12.0]

@interface TDDFontManager : NSObject

+ (NSString *)getDisplayFont;
+ (CGFloat)getFontSize_Display;


@end
