//
//  TDDColorManager.h
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#define kDEFAULT_WHITE_COLOR [UIColor whiteColor]
#define kDEFAULT_BLACK_COLOR [UIColor blackColor]
#define kDEFAULT_GRAY_COLOR [UIColor grayColor]
#define kDEFAULT_LIGHT_GRAY_COLOR [UIColor lightGrayColor]
#define kDEFAULT_DARK_TEXT_COLOR [UIColor darkTextColor]
#define kDEFAULT_LIGHTGRAY_COLOR [UIColor lightGrayColor]
#define kDEFAULT_GREEN_COLOR [UIColor greenColor]
#define kDEFAULT_CLEAR_COLOR [UIColor clearColor]

@interface TDDColorManager : NSObject

+(UIColor *)colorFromHexString:(NSString *)hexString;
+ (UIColor *)blueColor;
+ (UIColor *)blueSelectedColor;
+ (UIColor *)greenColor;
@end
