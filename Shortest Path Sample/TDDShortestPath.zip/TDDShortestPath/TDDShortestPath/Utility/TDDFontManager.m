//
//  TDDFontManager.m
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import "TDDFontManager.h"

@implementation TDDFontManager

// get font Halvetica

+ (NSString *)getDisplayFont {
    return @"Halvetica";
}
//Font Size
+ (CGFloat)getFontSize_Display {
    
    return 11.0;
}

@end
