//
//  TDDAppUtility.h
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Constant.h"
#import "TDDVertex.h"
#define kTitle @"TDD Shortest Path"

@interface TDDAppUtility : NSObject

+ (TDDAppUtility *)sharedInstance;
+ (void)showAlertViewWithTitle:(NSString *)title message:(NSString *)message cancelTitle:(NSString *)btnTitle;
+ (void)showAlertWithMessage:(NSString *)message cancelTitle:(NSString *)btnTitle;
+ (void)showAlertWithMessage:(NSString *)message;
+ (void)setUserPreferencesObject:(id)value forKey:(NSString *)key;
+ (id)getUserPreferencesObjectForKey:(NSString *)key;
+ (void)clearUserPreferenceObjectForKey:(NSString *)key;
@end
