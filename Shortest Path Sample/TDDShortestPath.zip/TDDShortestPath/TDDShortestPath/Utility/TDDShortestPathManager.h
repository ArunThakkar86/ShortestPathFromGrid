//
//  TDDShortestPathManager.h
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "TDDVertex.h"
#import "TDDAppUtility.h"

@interface TDDShortestPathManager : NSObject

+ (void)findShortestPath:(int)row andColoumn: (int)coloumn forGrid:(NSMutableArray * )gridMasterArray completionHandler:(void (^) (NSDictionary *responseDictionary))completionHandler;
+ (NSMutableArray *)seprateFirstColoumnElementFromGrid:(NSMutableArray *)gridArray;
+ (TDDVertex *)findStartingNodeFromGrid:(NSMutableArray *)gridArray;
+ (TDDVertex *)findMinChildVertexNodeOfVertex:(TDDVertex *)vtxCurrent FromArray:(NSMutableArray *)array;
+ (NSMutableDictionary *)formatSuccessResult:(NSMutableArray *)gridArray ofColoumn:(int)coloumn WithStartingVertext:(TDDVertex *)vtxStartNode;
+ (NSMutableDictionary *)formatFailureResult:(NSMutableArray *)gridArray ofColoumn:(int)coloumn WithStartingVertext:(TDDVertex *)vtxStartNode;
+ (NSMutableArray *)getDeepCopiedGridarrayFromMasterGridArray:(NSMutableArray *)gridMasterArray;
@end
