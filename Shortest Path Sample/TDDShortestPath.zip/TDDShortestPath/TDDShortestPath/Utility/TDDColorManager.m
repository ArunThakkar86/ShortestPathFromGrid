//
//  TDDColorManager.m
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import "TDDColorManager.h"

@implementation TDDColorManager

/*---------------------------------------------------------------------------
 * colorFromHexString
 * This method will be used to covert hexa value of color to related UIColor
 *--------------------------------------------------------------------------*/

+ (UIColor *)colorFromHexString:(NSString *)hexString
{
    unsigned rgbValue = 0;
    NSScanner *scanner = [NSScanner scannerWithString:hexString];
    [scanner setScanLocation:1]; // bypass '#' character
    [scanner scanHexInt:&rgbValue];
    return [UIColor colorWithRed:((rgbValue & 0xFF0000) >> 16)/255.0 green:((rgbValue & 0xFF00) >> 8)/255.0 blue:(rgbValue & 0xFF)/255.0 alpha:1.0];
}

/*---------------------------------------------------------------------------
 * blueColor
 * This method will be return custom blue color
 *--------------------------------------------------------------------------*/

+ (UIColor *)blueColor {
    return [TDDColorManager colorFromHexString:@"#17479D"];
}

/*---------------------------------------------------------------------------
 * blueSelectedColor
 * This method will be return custom blue selected color when button tapped
 *--------------------------------------------------------------------------*/
+ (UIColor *)blueSelectedColor{
    return [TDDColorManager colorFromHexString:@"#40A4C4"];
}

/*---------------------------------------------------------------------------
 * greenColor
 * This method will be return custom green color
 *--------------------------------------------------------------------------*/
+ (UIColor *)greenColor{
    return [TDDColorManager colorFromHexString:@"#0D5F1B"];}

@end
