//
//  TDDAppUtility.m
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import "TDDAppUtility.h"
#import "UIWindow+VisibleViewController.h"

@implementation TDDAppUtility

/*---------------------------------------------------------------------------
 * sharedInstance
 * creating static singleton object of the class TDDAppUtility
 *--------------------------------------------------------------------------*/
+ (TDDAppUtility *)sharedInstance {
    
    static dispatch_once_t onceToken;
    static id sharedInstance;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[super alloc] init];
    });
    
    return sharedInstance;
}

+ (id) alloc {
    return [self sharedInstance];
}

# pragma mark -  NSUserDefaults config -

/*---------------------------------------------------------------------------
 * setUserPreferencesObject
 * This method is used to store object in user default (persistant store)
 *--------------------------------------------------------------------------*/
+ (void)setUserPreferencesObject:(id)value forKey:(NSString *)key {
    [[NSUserDefaults standardUserDefaults] setObject:value forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

/*---------------------------------------------------------------------------
 * getUserPreferencesObjectForKey
 * This method is used to retrive object from user default (persistant store)
 *--------------------------------------------------------------------------*/
+ (id)getUserPreferencesObjectForKey:(NSString *)key {
    return [[NSUserDefaults standardUserDefaults] objectForKey:key];
}

/*---------------------------------------------------------------------------
 * clearUserPreferenceObjectForKey
 * This method is used to clear object from user default (persistant store)
 *--------------------------------------------------------------------------*/
+ (void)clearUserPreferenceObjectForKey:(NSString *)key{
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}


#pragma mark - general utility functions

+ (void)showAlertViewWithTitle:(NSString *)title message:(NSString *)message cancelTitle:(NSString *)btnTitle {
    [TDDAppUtility showAlertViewWithTitle:title message:message tag:0 cancelTitle:@"OK" ensureTitle:nil delegate:nil completionHandler:nil];
}

+ (void)showAlertWithMessage:(NSString *)message cancelTitle:(NSString *)btnTitle {
    [TDDAppUtility showAlertViewWithTitle:kTitle message:message tag:0 cancelTitle:@"OK" ensureTitle:nil delegate:nil completionHandler:nil];
}

+ (void)showAlertWithMessage:(NSString *)message {
    [TDDAppUtility showAlertViewWithTitle:kTitle message:message tag:0 cancelTitle:@"OK" ensureTitle:nil delegate:nil completionHandler:nil];
}
#pragma mark - show alert methods


+ (void)showAlertViewWithTitle:(NSString *)title message:(NSString *)message tag:(int)tag cancelTitle:(NSString *)btnTitle ensureTitle:(NSString *)ensureTitle delegate:(UIViewController *)delegate completionHandler:(void (^) (NSString *buttonTitle))completionHandler {
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if ([UIAlertController class])
        {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
            
            // cancel(first) button
            UIAlertAction *cancel = [UIAlertAction actionWithTitle:btnTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                                     {
                                         TDDLog(@"Cancel action");
                                         
                                         if(completionHandler != nil) {
                                             completionHandler(btnTitle);
                                         }
                                     }];
            [alertController addAction:cancel];
            
            // ensure(second) button
            if (ensureTitle) {
                UIAlertAction *ok = [UIAlertAction actionWithTitle:ensureTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
                                     {
                                         TDDLog(@"ensureTitle action");
                                         if(completionHandler != nil) {
                                             completionHandler(ensureTitle);
                                         }
                                     }];
                [alertController addAction:ok];
            }
            UIViewController *mainController = [UIWindow visibleViewController];
            [mainController presentViewController:alertController animated:YES completion:nil];
        } else {
            
            UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:title message:message delegate:delegate cancelButtonTitle:btnTitle otherButtonTitles:ensureTitle,nil];
            alertView.tag = tag;
            [alertView show];
        }
    });
}


@end
