//
//  TDDVertex.h
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TDDVertex : NSObject <NSCopying>
@property(nonatomic,strong)NSNumber* row;
@property(nonatomic,strong)NSNumber* column;
@property(nonatomic,strong)NSNumber* value;

- (id)copyWithZone:(NSZone *)zone;


@end
