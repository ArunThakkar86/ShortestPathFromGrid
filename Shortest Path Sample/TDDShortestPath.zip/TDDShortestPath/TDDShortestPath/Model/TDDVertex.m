//
//  TDDVertex.m
//  TDDShortestPath
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import "TDDVertex.h"

@implementation TDDVertex
@synthesize row, column,value;

/*---------------------------------------------------------------------------
 * copyWithZone
 * This method is implementation of NSCopying protocol to support deep copy
 * of TDDVertex object
 *--------------------------------------------------------------------------*/
-(id)copyWithZone:(NSZone *)zone
{
    // We'll ignore the zone for now
    TDDVertex *another = [[TDDVertex alloc] init];
    another.row = [row copyWithZone: zone];
    another.column = [column copyWithZone: zone];
    another.value = [value copyWithZone: zone];
    
    return another;
}
@end
