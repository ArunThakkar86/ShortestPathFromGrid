//
//  TDDShortestPathTests.m
//  TDDShortestPathTests
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "GridViewController.h"
#import "AppDelegate.h"
#import "TDDVertex.h"
#import "TDDShortestPathManager.h"

@interface TDDShortestPathTests : XCTestCase{
    
    AppDelegate *appDelegate;
    GridViewController *gridViewController;
    UIView             *gridView;
    NSMutableArray *defaultTestArray;
    
}

@end


@interface GridViewController (Test){
}


@end

@implementation TDDShortestPathTests

- (void)setUp {
    [super setUp];
    
    gridViewController = [[GridViewController alloc] init];
    XCTAssertNotNil(gridViewController, @"Cannot create GridViewController instance");
    
    /*---------------------------------------------------------------------------
     * Filling default test array to use for testing
     * default array of size 3 X 5 (i.e) 3 rows and 5 coloumn
     * rowOne = @"3",@"4",@"1",@"2",@"8";
     * rowTwo = @"6",@"1",@"8",@"2",@"7";
     * rowThree = @"5",@"9",@"3",@"9",@"9";
     *--------------------------------------------------------------------------*/
    
    TDDVertex *vtx00 = [[TDDVertex alloc] init];
    vtx00.row = [NSNumber numberWithInteger:0];
    vtx00.column = [NSNumber numberWithInteger:0];
    vtx00.value = [NSNumber numberWithInteger:3];
    
    TDDVertex *vtx01 = [[TDDVertex alloc] init];
    vtx01.row = [NSNumber numberWithInteger:0];
    vtx01.column = [NSNumber numberWithInteger:1];
    vtx01.value = [NSNumber numberWithInteger:4];
    
    TDDVertex *vtx02 = [[TDDVertex alloc] init];
    vtx02.row = [NSNumber numberWithInteger:0];
    vtx02.column = [NSNumber numberWithInteger:2];
    vtx02.value = [NSNumber numberWithInteger:1];
    
    
    TDDVertex *vtx03 = [[TDDVertex alloc] init];
    vtx03.row = [NSNumber numberWithInteger:0];
    vtx03.column = [NSNumber numberWithInteger:3];
    vtx03.value = [NSNumber numberWithInteger:2];
    
    TDDVertex *vtx04 = [[TDDVertex alloc] init];
    vtx04.row = [NSNumber numberWithInteger:0];
    vtx04.column = [NSNumber numberWithInteger:4];
    vtx04.value = [NSNumber numberWithInteger:8];
    
    //rowOne = @"3",@"4",@"1",@"2",@"8";
    NSMutableArray *arrayRowOne = [[NSMutableArray alloc] initWithObjects:vtx00,vtx01,vtx02,vtx03,vtx04, nil];
    

    TDDVertex *vtx10 = [[TDDVertex alloc] init];
    vtx10.row = [NSNumber numberWithInteger:1];
    vtx10.column = [NSNumber numberWithInteger:0];
    vtx10.value = [NSNumber numberWithInteger:6];
    
    
    TDDVertex *vtx11 = [[TDDVertex alloc] init];
    vtx11.row = [NSNumber numberWithInteger:1];
    vtx11.column = [NSNumber numberWithInteger:1];
    vtx11.value = [NSNumber numberWithInteger:1];
    
    TDDVertex *vtx12 = [[TDDVertex alloc] init];
    vtx12.row = [NSNumber numberWithInteger:1];
    vtx12.column = [NSNumber numberWithInteger:2];
    vtx12.value = [NSNumber numberWithInteger:8];
    
    TDDVertex *vtx13 = [[TDDVertex alloc] init];
    vtx13.row = [NSNumber numberWithInteger:1];
    vtx13.column = [NSNumber numberWithInteger:3];
    vtx13.value = [NSNumber numberWithInteger:2];
    
    TDDVertex *vtx14 = [[TDDVertex alloc] init];
    vtx14.row = [NSNumber numberWithInteger:1];
    vtx14.column = [NSNumber numberWithInteger:4];
    vtx14.value = [NSNumber numberWithInteger:7];
    
    //rowTwo = @"6",@"1",@"8",@"2",@"7";
    NSMutableArray *arrayRowTwo = [[NSMutableArray alloc] initWithObjects:vtx10,vtx11,vtx12,vtx13,vtx14, nil];
    

    TDDVertex *vtx20 = [[TDDVertex alloc] init];
    vtx20.row = [NSNumber numberWithInteger:1];
    vtx20.column = [NSNumber numberWithInteger:0];
    vtx20.value = [NSNumber numberWithInteger:5];
    
    TDDVertex *vtx21 = [[TDDVertex alloc] init];
    vtx21.row = [NSNumber numberWithInteger:1];
    vtx21.column = [NSNumber numberWithInteger:1];
    vtx21.value = [NSNumber numberWithInteger:9];
    
    
    TDDVertex *vtx22 = [[TDDVertex alloc] init];
    vtx22.row = [NSNumber numberWithInteger:1];
    vtx22.column = [NSNumber numberWithInteger:2];
    vtx22.value = [NSNumber numberWithInteger:3];
    
    
    TDDVertex *vtx23 = [[TDDVertex alloc] init];
    vtx23.row = [NSNumber numberWithInteger:1];
    vtx23.column = [NSNumber numberWithInteger:3];
    vtx23.value = [NSNumber numberWithInteger:9];
    
    TDDVertex *vtx24 = [[TDDVertex alloc] init];
    vtx24.row = [NSNumber numberWithInteger:1];
    vtx24.column = [NSNumber numberWithInteger:4];
    vtx24.value = [NSNumber numberWithInteger:9];
    
    //rowThree = @"5",@"9",@"3",@"9",@"9";
    NSMutableArray *arrayRowThree = [[NSMutableArray alloc] initWithObjects:vtx20,vtx21,vtx22,vtx23,vtx24, nil];
    
    defaultTestArray = [[NSMutableArray alloc] initWithObjects:arrayRowOne,arrayRowTwo,arrayRowThree, nil];

}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}


- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

/*---------------------------------------------------------------------------
 * testGridMasterShouldNotNil
 * This testcase method is used to check Grid Master Array not nil
 *--------------------------------------------------------------------------*/

- (void)testGridMasterShouldNotNil{
    int row = 2;
    int col = 5;
    [gridViewController initializeGridArrayWithRow:row AndColoumn:col];
    XCTAssertNotNil(gridViewController.gridMasterArray,@"Grid Master Array should not be nil");
}

/*---------------------------------------------------------------------------
 * testGridMasterShouldContainsValue
 * This testcase method is used to check Grid Master contains value or not
 *--------------------------------------------------------------------------*/
- (void)testGridMasterShouldContainsValue{
    int row = 2;
    int col = 5;
    [gridViewController initializeGridArrayWithRow:row AndColoumn:col];
    XCTAssertGreaterThan(gridViewController.gridMasterArray.count, 0);
}

/*---------------------------------------------------------------------------
 * testDefaultArrayShouldNotNill
 * This testcase method is used to check defaultArray not nill
 *--------------------------------------------------------------------------*/
- (void)testDefaultArrayShouldNotNill{
    [gridViewController setDefault:nil];
    XCTAssertNotNil(gridViewController.defaultArray,@"Grid Master Array should not be nil");
}

/*---------------------------------------------------------------------------
 * testDefaultArrayShouldContainsValue
 * This testcase method is used to check defaultArray contains value or not
 *--------------------------------------------------------------------------*/
- (void)testDefaultArrayShouldContainsValue{
    [gridViewController setDefault:nil];
    XCTAssertGreaterThan(gridViewController.defaultArray.count, 0);
}


/*---------------------------------------------------------------------------
 * testClearAll
 * This testcase method is used to check clear all clears Grid Master or not
 *--------------------------------------------------------------------------*/
- (void)testClearAll{
    [gridViewController clearAll:nil];
    XCTAssertNil(gridViewController.gridMasterArray,@"Grid Master Arrasy Should be nil");
    XCTAssertEqual(gridViewController.gridMasterArray.count, 0);
}

/*---------------------------------------------------------------------------
 * testDeepCopyOfMasterGridArray
 * This testcase method is used to check functionality of 
 * getDeepCopiedGridarrayFromMasterGridArray of TDDShortestPathManager
 *--------------------------------------------------------------------------*/
- (void)testDeepCopyOfMasterGridArray{
    int row = 2;
    int col = 5;
    [gridViewController initializeGridArrayWithRow:row AndColoumn:col];
    NSMutableArray *copiedArray = [TDDShortestPathManager getDeepCopiedGridarrayFromMasterGridArray:gridViewController.gridMasterArray];
     XCTAssertGreaterThan(copiedArray.count, 0);
    XCTAssertNotEqual(copiedArray, gridViewController.gridMasterArray);
}

/*---------------------------------------------------------------------------
 * testFindMinVertexFromArray
 * This testcase method is used to check functionality of
 * findMinChildVertexNodeOfVertex of TDDShortestPathManager get 
 * child with minimum value or not.
 *--------------------------------------------------------------------------*/
- (void)testFindMinVertexFromArray{
    TDDVertex *vtxCurrent = defaultTestArray[1][3];
    TDDVertex *minVertex = [TDDShortestPathManager findMinChildVertexNodeOfVertex:vtxCurrent FromArray:defaultTestArray];
    XCTAssertEqual([minVertex.value integerValue], 7);
    XCTAssertEqual([minVertex.row integerValue], 1);
    XCTAssertEqual([minVertex.column integerValue], 4);
    
}

/*---------------------------------------------------------------------------
 * testFindShortestPathFromArray
 * This testcase method takes default test array created during setup and 
 * evaluate working functionality to obtain correct result.
 *--------------------------------------------------------------------------*/
- (void)testFindShortestPathFromArray{
    [TDDShortestPathManager findShortestPath:3 andColoumn:5 forGrid:defaultTestArray completionHandler:^(NSDictionary *responseDictionary) {
        if(responseDictionary){
            
            XCTAssertEqual([responseDictionary objectForKey:@"PathExist"], @"Yes",@"Path must be exist for the given grid");
            NSNumber *minCost = [responseDictionary objectForKey:@"MinTotalCost"];
            XCTAssertEqual(minCost.integerValue , 14);
           
        }
    }];
}
- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
