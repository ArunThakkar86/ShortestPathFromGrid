//
//  TDDShortestPathUITests.m
//  TDDShortestPathUITests
//
//  Created by Zensar on 24/01/17.
//  Copyright © 2017 Arun. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "GridViewController.h"
#import "AppDelegate.h"


@interface TDDShortestPathUITests : XCTestCase{
    
    AppDelegate *appDelegate;
    GridViewController *gridViewController;
    UIView             *gridView;

}

@end

@implementation TDDShortestPathUITests

- (void)setUp {
    [super setUp];
    
    // Put setup code here. This method is called before the invocation of each test method in the class.
    
    // In UI tests it is usually best to stop immediately when a failure occurs.
    self.continueAfterFailure = NO;
    // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
    [[[XCUIApplication alloc] init] launch];
    
}

/*---------------------------------------------------------------------------
 * testEmptyRow
 * This testcase method evaluates as text field row should not be blank
 *--------------------------------------------------------------------------*/
- (void)testEmptyRow{
    
    XCUIApplication *app = [[XCUIApplication alloc] init];
    [app.buttons[@"GO"] tap];
    [app.alerts[@"TDD Shortest Path"].collectionViews.buttons[@"OK"] tap];
    
}

/*---------------------------------------------------------------------------
 * testEmptyColoumn
 * This testcase method evaluates as text field coloumn should not be blank
 *--------------------------------------------------------------------------*/
- (void)testEmptyColoumn{
    
    XCUIApplication *app = [[XCUIApplication alloc] init];
    XCUIElement *element = [[[[[app childrenMatchingType:XCUIElementTypeWindow] elementBoundByIndex:0] childrenMatchingType:XCUIElementTypeOther].element childrenMatchingType:XCUIElementTypeOther] elementBoundByIndex:1];
    [[[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0] tap];
    [[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0];
    XCUIElement *key = app.keyboards.keys[@"3"];
    [key tap];
    [app.toolbars.buttons[@"Done"] tap];
    [app.buttons[@"GO"] tap];
    [app.alerts[@"TDD Shortest Path"].collectionViews.buttons[@"OK"] tap];
    
}

/*---------------------------------------------------------------------------
 * testMinRow
 * This testcase method evaluates as minimum value of row is 1
 *--------------------------------------------------------------------------*/
- (void)testMinRow{
    
    XCUIApplication *app = [[XCUIApplication alloc] init];
    XCUIElement *element = [[[[[app childrenMatchingType:XCUIElementTypeWindow] elementBoundByIndex:0] childrenMatchingType:XCUIElementTypeOther].element childrenMatchingType:XCUIElementTypeOther] elementBoundByIndex:1];
    [[[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0] tap];
    [[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0];
    XCUIElement *keyZero = app.keyboards.keys[@"0"];
    [keyZero tap];
    [[[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:1] tap];
    [[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:1];
    XCUIElement *keyFive = app.keyboards.keys[@"5"];
    [keyFive tap];
    [app.toolbars.buttons[@"Done"] tap];
    [app.buttons[@"GO"] tap];
    [app.alerts[@"TDD Shortest Path"].collectionViews.buttons[@"OK"] tap];
    
}

/*---------------------------------------------------------------------------
 * testMaxRow
 * This testcase method evaluates as maximum value of row is 5
 *--------------------------------------------------------------------------*/
- (void)testMaxRow{
    
    XCUIApplication *app = [[XCUIApplication alloc] init];
    XCUIElement *element = [[[[[app childrenMatchingType:XCUIElementTypeWindow] elementBoundByIndex:0] childrenMatchingType:XCUIElementTypeOther].element childrenMatchingType:XCUIElementTypeOther] elementBoundByIndex:1];
    [[[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0] tap];
    [[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0];
    XCUIElement *keyZero = app.keyboards.keys[@"6"];
    [keyZero tap];
    [[[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:1] tap];
    [[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:1];
    XCUIElement *keyFive = app.keyboards.keys[@"5"];
    [keyFive tap];
    [app.toolbars.buttons[@"Done"] tap];
    [app.buttons[@"GO"] tap];
    [app.alerts[@"TDD Shortest Path"].collectionViews.buttons[@"OK"] tap];

}

/*---------------------------------------------------------------------------
 * testMinColoumn
 * This testcase method evaluates as minimum value of coloumn is 5
 *--------------------------------------------------------------------------*/
- (void)testMinColoumn{
    
    XCUIApplication *app = [[XCUIApplication alloc] init];
    XCUIElement *element = [[[[[app childrenMatchingType:XCUIElementTypeWindow] elementBoundByIndex:0] childrenMatchingType:XCUIElementTypeOther].element childrenMatchingType:XCUIElementTypeOther] elementBoundByIndex:1];
    [[[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0] tap];
    [[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0];
    XCUIElement *keyTwo = app.keyboards.keys[@"2"];
    [keyTwo tap];
    [[[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:1] tap];
    [[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:1];
    XCUIElement *keyThree = app.keyboards.keys[@"3"];
    [keyThree tap];
    [app.toolbars.buttons[@"Done"] tap];
    [app.buttons[@"GO"] tap];
    [app.alerts[@"TDD Shortest Path"].collectionViews.buttons[@"OK"] tap];
    
}

/*---------------------------------------------------------------------------
 * testMaxColoumn
 * This testcase method evaluates as maximum value of coloumn is 10
 *--------------------------------------------------------------------------*/
- (void)testMaxColoumn{
    XCUIApplication *app = [[XCUIApplication alloc] init];
    XCUIElement *element = [[[[[app childrenMatchingType:XCUIElementTypeWindow] elementBoundByIndex:0] childrenMatchingType:XCUIElementTypeOther].element childrenMatchingType:XCUIElementTypeOther] elementBoundByIndex:1];
    [[[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0] tap];
    [[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0];
    XCUIElement *keyTwo = app.keyboards.keys[@"2"];
    [keyTwo tap];
    [[[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:1] tap];
    [[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:1];
    XCUIElement *keyOne = app.keyboards.keys[@"1"];
    [keyOne tap];
    [keyOne tap];
    [app.toolbars.buttons[@"Done"] tap];
    [app.buttons[@"GO"] tap];
    [app.alerts[@"TDD Shortest Path"].collectionViews.buttons[@"OK"] tap];

}

/*---------------------------------------------------------------------------
 * testEmptyGrid
 * This testcase method evaluates all values of grid should be filled or not
 *--------------------------------------------------------------------------*/
- (void)testEmptyGrid{

    XCUIApplication *app = [[XCUIApplication alloc] init];
    XCUIElement *element = [[[[[app childrenMatchingType:XCUIElementTypeWindow] elementBoundByIndex:0] childrenMatchingType:XCUIElementTypeOther].element childrenMatchingType:XCUIElementTypeOther] elementBoundByIndex:1];
    [[[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0] tap];
    [[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0];
    XCUIElement *keyTwo = app.keyboards.keys[@"2"];
    [keyTwo tap];
    [[[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:1] tap];
    [[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:1];
    XCUIElement *keyFive = app.keyboards.keys[@"5"];
    [keyFive tap];
    [app.toolbars.buttons[@"Done"] tap];
    [app.buttons[@"GO"] tap];
    [app.buttons[@"Find Shortest Path"] tap];
    [app.alerts[@"TDD Shortest Path"].collectionViews.buttons[@"OK"] tap];
}

/*---------------------------------------------------------------------------
 * testGrid
 * This testcase method evaluates enterd grid values and find shortest path
 *--------------------------------------------------------------------------*/
- (void)testGrid{
    
    XCUIApplication *app = [[XCUIApplication alloc] init];
    XCUIElement *element = [[[[[app childrenMatchingType:XCUIElementTypeWindow] elementBoundByIndex:0] childrenMatchingType:XCUIElementTypeOther].element childrenMatchingType:XCUIElementTypeOther] elementBoundByIndex:1];
    [[[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0] tap];
    [[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0];
    XCUIElement *keyTwo = app.keyboards.keys[@"2"];
    [keyTwo tap];
    [[[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:1] tap];
    [[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:1];
    XCUIElement *keyFive = app.keyboards.keys[@"5"];
    [keyFive tap];
    XCUIElement *doneButton = app.toolbars.buttons[@"Done"];
    [doneButton tap];
    [app.buttons[@"GO"] tap];
    
    XCUIElement *keyFour = app.keyboards.keys[@"4"];
    XCUIElement *keyOne = app.keyboards.keys[@"1"];
    XCUIElement *keyEight = app.keyboards.keys[@"8"];
    XCUIElement *keyThree = app.keyboards.keys[@"3"];
    XCUIElement *keySix = app.keyboards.keys[@"6"];
    
    XCUIElementQuery *collectionViewsQuery = app.collectionViews;
    XCUIElementQuery *elementsQuery = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:0].otherElements;
    [[elementsQuery childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery childrenMatchingType:XCUIElementTypeTextField].element;
    [keyFive tap];
    XCUIElementQuery *elementsQuery2 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:1].otherElements;
    [[elementsQuery2 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery2 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyTwo tap];
    XCUIElementQuery *elementsQuery3 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:2].otherElements;
    [[elementsQuery3 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery3 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyEight tap];
    XCUIElementQuery *elementsQuery4 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:3].otherElements;
    [[elementsQuery4 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery4 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyThree tap];
    XCUIElementQuery *elementsQuery5 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:4].otherElements;
    [[elementsQuery5 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery5 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyFour tap];
    XCUIElementQuery *elementsQuery6 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:5].otherElements;
    [[elementsQuery6 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery6 childrenMatchingType:XCUIElementTypeTextField].element;
    [keySix tap];
    XCUIElementQuery *elementsQuery7 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:6].otherElements;
    [[elementsQuery7 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery7 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyTwo tap];
    XCUIElementQuery *elementsQuery8 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:7].otherElements;
    [[elementsQuery8 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery8 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyOne tap];
    XCUIElementQuery *elementsQuery9 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:8].otherElements;
    [[elementsQuery9 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery9 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyFour tap];
    XCUIElementQuery *elementsQuery10 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:9].otherElements;
    [[elementsQuery10 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery10 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyFive tap];
    
    [doneButton tap];
    [app.buttons[@"Find Shortest Path"] tap];
    
}

/*---------------------------------------------------------------------------
 * testClearAll
 * This testcase method evaluates clearance of Grid values
 *--------------------------------------------------------------------------*/
- (void)testClearAll{
    
    XCUIApplication *app = [[XCUIApplication alloc] init];
    XCUIElement *element = [[[[[app childrenMatchingType:XCUIElementTypeWindow] elementBoundByIndex:0] childrenMatchingType:XCUIElementTypeOther].element childrenMatchingType:XCUIElementTypeOther] elementBoundByIndex:1];
    [[[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0] tap];
    [[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:0];
    XCUIElement *keyTwo = app.keyboards.keys[@"2"];
    [keyTwo tap];
    [[[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:1] tap];
    [[element childrenMatchingType:XCUIElementTypeTextField] elementBoundByIndex:1];
    XCUIElement *keyFive = app.keyboards.keys[@"5"];
    [keyFive tap];
    XCUIElement *doneButton = app.toolbars.buttons[@"Done"];
    [doneButton tap];
    [app.buttons[@"GO"] tap];
    
    XCUIElement *keyFour = app.keyboards.keys[@"4"];
    XCUIElement *keyOne = app.keyboards.keys[@"1"];
    XCUIElement *keyEight = app.keyboards.keys[@"8"];
    XCUIElement *keyThree = app.keyboards.keys[@"3"];
    XCUIElement *keySix = app.keyboards.keys[@"6"];
    
    XCUIElementQuery *collectionViewsQuery = app.collectionViews;
    XCUIElementQuery *elementsQuery = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:0].otherElements;
    [[elementsQuery childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery childrenMatchingType:XCUIElementTypeTextField].element;
    [keyFive tap];
    XCUIElementQuery *elementsQuery2 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:1].otherElements;
    [[elementsQuery2 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery2 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyTwo tap];
    XCUIElementQuery *elementsQuery3 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:2].otherElements;
    [[elementsQuery3 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery3 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyEight tap];
    XCUIElementQuery *elementsQuery4 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:3].otherElements;
    [[elementsQuery4 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery4 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyThree tap];
    XCUIElementQuery *elementsQuery5 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:4].otherElements;
    [[elementsQuery5 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery5 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyFour tap];
    XCUIElementQuery *elementsQuery6 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:5].otherElements;
    [[elementsQuery6 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery6 childrenMatchingType:XCUIElementTypeTextField].element;
    [keySix tap];
    XCUIElementQuery *elementsQuery7 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:6].otherElements;
    [[elementsQuery7 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery7 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyTwo tap];
    XCUIElementQuery *elementsQuery8 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:7].otherElements;
    [[elementsQuery8 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery8 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyOne tap];
    XCUIElementQuery *elementsQuery9 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:8].otherElements;
    [[elementsQuery9 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery9 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyFour tap];
    XCUIElementQuery *elementsQuery10 = [[collectionViewsQuery childrenMatchingType:XCUIElementTypeCell] elementBoundByIndex:9].otherElements;
    [[elementsQuery10 childrenMatchingType:XCUIElementTypeTextField].element tap];
    [elementsQuery10 childrenMatchingType:XCUIElementTypeTextField].element;
    [keyFive tap];
    [doneButton tap];
    
    [app.buttons[@"Clear All"] tap];
    
}

/*---------------------------------------------------------------------------
 * testDefault
 * This testcase method evaluates working functionality of default button
 *--------------------------------------------------------------------------*/
- (void)testDefault{
    
    XCUIApplication *app = [[XCUIApplication alloc] init];
    [app.buttons[@"Default"] tap];
    [app.buttons[@"Find Shortest Path"] tap];
    
}

@end
